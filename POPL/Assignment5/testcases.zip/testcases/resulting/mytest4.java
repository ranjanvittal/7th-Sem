class mytest4 {
public static void main(String[] original_micro_a) {
new original_new_mytest4().original_print(new Runner());
}
}
class original_new_mytest4 {
public void original_print(Runner var_1) {
original_Division original_a;
Class1 var_2;
original_a = new original_Division();
original_a = new original_Division();
var_2 = new Class1();
var_2.var_1 = var_1;
var_2.original_a = original_a;
var_2.latest_class_3 = this;
original_a.original_divide(200, 20, var_2);
}
}
class original_Division {
public void original_divide(int original_a, int original_b, Runner var_5) {
int original_val;
int original_i;
Class3 var_6;
original_val = 0;
original_i = 0;
original_i = 0;
original_val = original_b * original_i;
var_6 = new Class3();
var_6.original_val = original_val;
var_6.original_b = original_b;
var_6.original_a = original_a;
var_6.original_i = original_i;
var_6.var_5 = var_5;
var_6.latest_class_7 = this;
var_6.run();
}
}
class original_DiffDivsion extends original_Division{
public void original_divide(int original_a, int original_b, Runner var_17) {
int original_val;
int original_i;
Class12 var_18;
original_val = 0;
original_i = 0;
original_i = 0;
original_val = original_b * original_i;
var_18 = new Class12();
var_18.original_val = original_val;
var_18.original_b = original_b;
var_18.original_a = original_a;
var_18.var_17 = var_17;
var_18.original_i = original_i;
var_18.latest_class_19 = this;
var_18.run();
}
}
class original_extra_array {
int[] original_first;
}
class original_extra_int {
int original_first;
}
class original_extra_boolean {
boolean original_first;
}
class Runner {
public void run() {
}
}
class Class2 extends Runner {
Runner var_1;
original_Division original_a;
original_new_mytest4 latest_class_3;
public void run() {
var_1.run();
}
}
class Class1 extends Runner {
Runner var_1;
original_Division original_a;
original_new_mytest4 latest_class_3;
Class2 var_4;
public void run() {
original_a = new original_DiffDivsion();
var_4 = new Class2();
var_4.var_1 = var_1;
var_4.original_a = original_a;
var_4.latest_class_3 = latest_class_3;
original_a.original_divide(1000, 22, var_4);
}
}
class Class4 extends Runner {
int original_val;
int original_b;
int original_a;
Class3 var_8;
original_Division latest_class_7;
int original_i;
Runner var_5;
Class5 var_10;
Class6 var_11;
Class8 var_13;
public void run() {
if(original_val < original_a)
{
var_10 = new Class5();
var_10.original_val = original_val;
var_10.original_b = original_b;
var_10.original_a = original_a;
var_10.var_8 = var_8;
var_10.latest_class_7 = latest_class_7;
var_10.original_i = original_i;
var_10.var_5 = var_5;
var_10.var_10 = var_10;
var_10.var_11 = var_11;
var_10.run();
}
else
{
var_11 = new Class6();
var_11.original_val = original_val;
var_11.original_b = original_b;
var_11.original_a = original_a;
var_11.var_8 = var_8;
var_11.latest_class_7 = latest_class_7;
var_11.original_i = original_i;
var_11.var_5 = var_5;
var_11.var_10 = var_10;
var_11.var_11 = var_11;
var_11.run();
}
}
}
class Class5 extends Runner {
int original_val;
int original_b;
int original_a;
Class3 var_8;
original_Division latest_class_7;
int original_i;
Runner var_5;
Class5 var_10;
Class6 var_11;
Class8 var_13;
public void run() {
original_i = original_i + 1;
original_val = original_b * original_i;
var_8.original_val = original_val;
var_8.original_b = original_b;
var_8.original_a = original_a;
var_8.var_8 = var_8;
var_8.latest_class_7 = latest_class_7;
var_8.original_i = original_i;
var_8.var_5 = var_5;
var_8.run();
}
}
class Class6 extends Runner {
int original_val;
int original_b;
int original_a;
Class3 var_8;
original_Division latest_class_7;
int original_i;
Runner var_5;
Class5 var_10;
Class6 var_11;
Class8 var_13;
public void run() {
var_13 = new Class8();
var_13.original_i = original_i;
var_13.var_11 = var_11;
var_13.latest_class_7 = latest_class_7;
var_13.var_10 = var_10;
var_13.original_b = original_b;
var_13.original_a = original_a;
var_13.original_val = original_val;
var_13.var_8 = var_8;
var_13.var_5 = var_5;
var_13.run();
}
}
class Class8 extends Runner {
int original_i;
Class6 var_11;
original_Division latest_class_7;
Class5 var_10;
int original_b;
int original_a;
int original_val;
Class3 var_8;
Runner var_5;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
if(original_a < original_val)
{
var_14 = new Class9();
var_16 = new Class11();
var_14.original_i = original_i;
var_14.var_11 = var_11;
var_14.latest_class_7 = latest_class_7;
var_14.var_10 = var_10;
var_14.original_b = original_b;
var_14.original_a = original_a;
var_14.original_val = original_val;
var_14.var_8 = var_8;
var_14.var_5 = var_5;
var_14.var_14 = var_14;
var_14.var_15 = var_15;
var_14.var_16 = var_16;
var_14.run();
}
else
{
var_15 = new Class10();
var_16 = new Class11();
var_15.original_i = original_i;
var_15.var_11 = var_11;
var_15.latest_class_7 = latest_class_7;
var_15.var_10 = var_10;
var_15.original_b = original_b;
var_15.original_a = original_a;
var_15.original_val = original_val;
var_15.var_8 = var_8;
var_15.var_5 = var_5;
var_15.var_14 = var_14;
var_15.var_15 = var_15;
var_15.var_16 = var_16;
var_15.run();
}
}
}
class Class9 extends Runner {
int original_i;
Class6 var_11;
original_Division latest_class_7;
Class5 var_10;
int original_b;
int original_a;
int original_val;
Class3 var_8;
Runner var_5;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
original_i = original_i - 1;
var_16.original_i = original_i;
var_16.var_11 = var_11;
var_16.latest_class_7 = latest_class_7;
var_16.var_10 = var_10;
var_16.original_b = original_b;
var_16.original_a = original_a;
var_16.original_val = original_val;
var_16.var_8 = var_8;
var_16.var_5 = var_5;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.original_i = original_i;
var_16.var_11 = var_11;
var_16.latest_class_7 = latest_class_7;
var_16.var_10 = var_10;
var_16.original_b = original_b;
var_16.original_a = original_a;
var_16.original_val = original_val;
var_16.var_8 = var_8;
var_16.var_5 = var_5;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.run();
}
}
class Class10 extends Runner {
int original_i;
Class6 var_11;
original_Division latest_class_7;
Class5 var_10;
int original_b;
int original_a;
int original_val;
Class3 var_8;
Runner var_5;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
var_16.original_i = original_i;
var_16.var_11 = var_11;
var_16.latest_class_7 = latest_class_7;
var_16.var_10 = var_10;
var_16.original_b = original_b;
var_16.original_a = original_a;
var_16.original_val = original_val;
var_16.var_8 = var_8;
var_16.var_5 = var_5;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.original_i = original_i;
var_16.var_11 = var_11;
var_16.latest_class_7 = latest_class_7;
var_16.var_10 = var_10;
var_16.original_b = original_b;
var_16.original_a = original_a;
var_16.original_val = original_val;
var_16.var_8 = var_8;
var_16.var_5 = var_5;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.run();
}
}
class Class11 extends Runner {
int original_i;
Class6 var_11;
original_Division latest_class_7;
Class5 var_10;
int original_b;
int original_a;
int original_val;
Class3 var_8;
Runner var_5;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
System.out.println(original_i);
var_5.run();
}
}
class Class3 extends Runner {
int original_val;
int original_b;
int original_a;
int original_i;
Runner var_5;
original_Division latest_class_7;
Class3 var_8;
Class4 var_9;
public void run() {
var_8 = new Class3();
var_9 = new Class4();
var_9.original_val = original_val;
var_9.original_b = original_b;
var_9.original_a = original_a;
var_9.var_8 = var_8;
var_9.latest_class_7 = latest_class_7;
var_9.original_i = original_i;
var_9.var_5 = var_5;
var_9.run();
}
}
class Class13 extends Runner {
int original_val;
int original_b;
Class12 var_20;
int original_a;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
Class14 var_22;
Class15 var_23;
Class17 var_25;
public void run() {
if(original_val < original_a)
{
var_22 = new Class14();
var_22.original_val = original_val;
var_22.original_b = original_b;
var_22.var_20 = var_20;
var_22.original_a = original_a;
var_22.var_17 = var_17;
var_22.original_i = original_i;
var_22.latest_class_19 = latest_class_19;
var_22.var_22 = var_22;
var_22.var_23 = var_23;
var_22.run();
}
else
{
var_23 = new Class15();
var_23.original_val = original_val;
var_23.original_b = original_b;
var_23.var_20 = var_20;
var_23.original_a = original_a;
var_23.var_17 = var_17;
var_23.original_i = original_i;
var_23.latest_class_19 = latest_class_19;
var_23.var_22 = var_22;
var_23.var_23 = var_23;
var_23.run();
}
}
}
class Class14 extends Runner {
int original_val;
int original_b;
Class12 var_20;
int original_a;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
Class14 var_22;
Class15 var_23;
Class17 var_25;
public void run() {
original_val = original_val + original_b;
original_i = original_i + 1;
var_20.original_val = original_val;
var_20.original_b = original_b;
var_20.var_20 = var_20;
var_20.original_a = original_a;
var_20.var_17 = var_17;
var_20.original_i = original_i;
var_20.latest_class_19 = latest_class_19;
var_20.run();
}
}
class Class15 extends Runner {
int original_val;
int original_b;
Class12 var_20;
int original_a;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
Class14 var_22;
Class15 var_23;
Class17 var_25;
public void run() {
var_25 = new Class17();
var_25.var_23 = var_23;
var_25.var_22 = var_22;
var_25.var_20 = var_20;
var_25.var_17 = var_17;
var_25.original_i = original_i;
var_25.latest_class_19 = latest_class_19;
var_25.original_b = original_b;
var_25.original_a = original_a;
var_25.original_val = original_val;
var_25.run();
}
}
class Class17 extends Runner {
Class15 var_23;
Class14 var_22;
Class12 var_20;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
int original_b;
int original_a;
int original_val;
Class18 var_26;
Class19 var_27;
Class20 var_28;
public void run() {
if(original_a < original_val)
{
var_26 = new Class18();
var_28 = new Class20();
var_26.var_23 = var_23;
var_26.var_22 = var_22;
var_26.var_20 = var_20;
var_26.var_17 = var_17;
var_26.original_i = original_i;
var_26.latest_class_19 = latest_class_19;
var_26.original_b = original_b;
var_26.original_a = original_a;
var_26.original_val = original_val;
var_26.var_26 = var_26;
var_26.var_27 = var_27;
var_26.var_28 = var_28;
var_26.run();
}
else
{
var_27 = new Class19();
var_28 = new Class20();
var_27.var_23 = var_23;
var_27.var_22 = var_22;
var_27.var_20 = var_20;
var_27.var_17 = var_17;
var_27.original_i = original_i;
var_27.latest_class_19 = latest_class_19;
var_27.original_b = original_b;
var_27.original_a = original_a;
var_27.original_val = original_val;
var_27.var_26 = var_26;
var_27.var_27 = var_27;
var_27.var_28 = var_28;
var_27.run();
}
}
}
class Class18 extends Runner {
Class15 var_23;
Class14 var_22;
Class12 var_20;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
int original_b;
int original_a;
int original_val;
Class18 var_26;
Class19 var_27;
Class20 var_28;
public void run() {
original_i = original_i - 1;
var_28.var_23 = var_23;
var_28.var_22 = var_22;
var_28.var_20 = var_20;
var_28.var_17 = var_17;
var_28.original_i = original_i;
var_28.latest_class_19 = latest_class_19;
var_28.original_b = original_b;
var_28.original_a = original_a;
var_28.original_val = original_val;
var_28.var_26 = var_26;
var_28.var_27 = var_27;
var_28.var_28 = var_28;
var_28.var_23 = var_23;
var_28.var_22 = var_22;
var_28.var_20 = var_20;
var_28.var_17 = var_17;
var_28.original_i = original_i;
var_28.latest_class_19 = latest_class_19;
var_28.original_b = original_b;
var_28.original_a = original_a;
var_28.original_val = original_val;
var_28.var_26 = var_26;
var_28.var_27 = var_27;
var_28.var_28 = var_28;
var_28.run();
}
}
class Class19 extends Runner {
Class15 var_23;
Class14 var_22;
Class12 var_20;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
int original_b;
int original_a;
int original_val;
Class18 var_26;
Class19 var_27;
Class20 var_28;
public void run() {
var_28.var_23 = var_23;
var_28.var_22 = var_22;
var_28.var_20 = var_20;
var_28.var_17 = var_17;
var_28.original_i = original_i;
var_28.latest_class_19 = latest_class_19;
var_28.original_b = original_b;
var_28.original_a = original_a;
var_28.original_val = original_val;
var_28.var_26 = var_26;
var_28.var_27 = var_27;
var_28.var_28 = var_28;
var_28.var_23 = var_23;
var_28.var_22 = var_22;
var_28.var_20 = var_20;
var_28.var_17 = var_17;
var_28.original_i = original_i;
var_28.latest_class_19 = latest_class_19;
var_28.original_b = original_b;
var_28.original_a = original_a;
var_28.original_val = original_val;
var_28.var_26 = var_26;
var_28.var_27 = var_27;
var_28.var_28 = var_28;
var_28.run();
}
}
class Class20 extends Runner {
Class15 var_23;
Class14 var_22;
Class12 var_20;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
int original_b;
int original_a;
int original_val;
Class18 var_26;
Class19 var_27;
Class20 var_28;
public void run() {
System.out.println(original_i);
var_17.run();
}
}
class Class12 extends Runner {
int original_val;
int original_b;
int original_a;
Runner var_17;
int original_i;
original_DiffDivsion latest_class_19;
Class12 var_20;
Class13 var_21;
public void run() {
var_20 = new Class12();
var_21 = new Class13();
var_21.original_val = original_val;
var_21.original_b = original_b;
var_21.var_20 = var_20;
var_21.original_a = original_a;
var_21.var_17 = var_17;
var_21.original_i = original_i;
var_21.latest_class_19 = latest_class_19;
var_21.run();
}
}
