class mytest1 {
public static void main(String[] original_micro_a) {
new original_new_mytest1().original_print(new Runner());
}
}
class original_new_mytest1 {
public void original_print(Runner var_1) {
original_extra_int original_a1;
int original_a2;
original_a1 = new original_extra_int();
original_a2 = 0;
original_a2 = 3;
System.out.println(original_a2);
var_1.run();
}
}
class Runner {
public void run() {
}
}
