class ExpressionTester {
public static void main(String[] original_a) {
new original_realMain().original_mainFunction(new Runner());
}
}
class original_c1 {
boolean original_real;
public void original_callFunction(Runner var_1) {
boolean original_unreal;
original_c1 original_ob1;
int[] original_arr;
Class1 var_2;
original_unreal = false;
original_ob1 = new original_c1();
original_arr = new int [1];
original_arr = new int [1];
original_arr[0] = 5;
original_ob1 = this;
original_unreal = !original_real;
var_2 = new Class1();
var_2.var_1 = var_1;
var_2.original_ob1 = original_ob1;
var_2.original_arr = original_arr;
var_2.original_unreal = original_unreal;
var_2.latest_class_3 = this;
var_2.run();
}
}
class original_realMain {
public void original_mainFunction(Runner var_12) {
original_c1 original_c1Object1;
Class10 var_13;
original_c1Object1 = new original_c1();
original_c1Object1 = new original_c1();
original_c1Object1.original_real = false;
var_13 = new Class10();
var_13.var_12 = var_12;
var_13.original_c1Object1 = original_c1Object1;
var_13.latest_class_14 = this;
original_c1Object1.original_callFunction(var_13);
}
}
class Runner {
public void run() {
}
}
class Class1 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
original_c1 latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
boolean final_1;
boolean final_2;
final_1 = latest_class_3.original_real;
final_2 = latest_class_3.original_real;
if(final_1 & final_2)
{
var_4 = new Class2();
var_6 = new Class4();
var_4.var_1 = var_1;
var_4.original_ob1 = original_ob1;
var_4.original_arr = original_arr;
var_4.original_unreal = original_unreal;
var_4.latest_class_3 = latest_class_3;
var_4.var_4 = var_4;
var_4.var_5 = var_5;
var_4.var_6 = var_6;
var_4.run();
}
else
{
var_5 = new Class3();
var_6 = new Class4();
var_5.var_1 = var_1;
var_5.original_ob1 = original_ob1;
var_5.original_arr = original_arr;
var_5.original_unreal = original_unreal;
var_5.latest_class_3 = latest_class_3;
var_5.var_4 = var_4;
var_5.var_5 = var_5;
var_5.var_6 = var_6;
var_5.run();
}
}
}
class Class2 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
original_c1 latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
System.out.println(1);
var_6.var_1 = var_1;
var_6.original_ob1 = original_ob1;
var_6.original_arr = original_arr;
var_6.original_unreal = original_unreal;
var_6.latest_class_3 = latest_class_3;
var_6.var_4 = var_4;
var_6.var_5 = var_5;
var_6.var_6 = var_6;
var_6.var_1 = var_1;
var_6.original_ob1 = original_ob1;
var_6.original_arr = original_arr;
var_6.original_unreal = original_unreal;
var_6.latest_class_3 = latest_class_3;
var_6.var_4 = var_4;
var_6.var_5 = var_5;
var_6.var_6 = var_6;
var_6.run();
}
}
class Class3 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
original_c1 latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
System.out.println(0);
var_7 = new Class5();
var_7.var_1 = var_1;
var_7.original_ob1 = original_ob1;
var_7.original_arr = original_arr;
var_7.original_unreal = original_unreal;
var_7.var_6 = var_6;
var_7.var_5 = var_5;
var_7.var_4 = var_4;
var_7.latest_class_3 = latest_class_3;
var_7.run();
}
}
class Class5 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
Class4 var_6;
Class3 var_5;
Class2 var_4;
original_c1 latest_class_3;
Class6 var_8;
Class7 var_9;
Class8 var_10;
Class9 var_11;
public void run() {
if(original_unreal & original_unreal)
{
var_8 = new Class6();
var_10 = new Class8();
var_8.var_1 = var_1;
var_8.original_ob1 = original_ob1;
var_8.original_arr = original_arr;
var_8.original_unreal = original_unreal;
var_8.var_6 = var_6;
var_8.var_5 = var_5;
var_8.var_4 = var_4;
var_8.latest_class_3 = latest_class_3;
var_8.var_8 = var_8;
var_8.var_9 = var_9;
var_8.var_10 = var_10;
var_8.run();
}
else
{
var_9 = new Class7();
var_10 = new Class8();
var_9.var_1 = var_1;
var_9.original_ob1 = original_ob1;
var_9.original_arr = original_arr;
var_9.original_unreal = original_unreal;
var_9.var_6 = var_6;
var_9.var_5 = var_5;
var_9.var_4 = var_4;
var_9.latest_class_3 = latest_class_3;
var_9.var_8 = var_8;
var_9.var_9 = var_9;
var_9.var_10 = var_10;
var_9.run();
}
}
}
class Class6 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
Class4 var_6;
Class3 var_5;
Class2 var_4;
original_c1 latest_class_3;
Class6 var_8;
Class7 var_9;
Class8 var_10;
Class9 var_11;
public void run() {
System.out.println(1);
var_10.var_1 = var_1;
var_10.original_ob1 = original_ob1;
var_10.original_arr = original_arr;
var_10.original_unreal = original_unreal;
var_10.var_6 = var_6;
var_10.var_5 = var_5;
var_10.var_4 = var_4;
var_10.latest_class_3 = latest_class_3;
var_10.var_8 = var_8;
var_10.var_9 = var_9;
var_10.var_10 = var_10;
var_10.var_1 = var_1;
var_10.original_ob1 = original_ob1;
var_10.original_arr = original_arr;
var_10.original_unreal = original_unreal;
var_10.var_6 = var_6;
var_10.var_5 = var_5;
var_10.var_4 = var_4;
var_10.latest_class_3 = latest_class_3;
var_10.var_8 = var_8;
var_10.var_9 = var_9;
var_10.var_10 = var_10;
var_10.run();
}
}
class Class7 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
Class4 var_6;
Class3 var_5;
Class2 var_4;
original_c1 latest_class_3;
Class6 var_8;
Class7 var_9;
Class8 var_10;
Class9 var_11;
public void run() {
var_10.var_1 = var_1;
var_10.original_ob1 = original_ob1;
var_10.original_arr = original_arr;
var_10.original_unreal = original_unreal;
var_10.var_6 = var_6;
var_10.var_5 = var_5;
var_10.var_4 = var_4;
var_10.latest_class_3 = latest_class_3;
var_10.var_8 = var_8;
var_10.var_9 = var_9;
var_10.var_10 = var_10;
var_10.var_1 = var_1;
var_10.original_ob1 = original_ob1;
var_10.original_arr = original_arr;
var_10.original_unreal = original_unreal;
var_10.var_6 = var_6;
var_10.var_5 = var_5;
var_10.var_4 = var_4;
var_10.latest_class_3 = latest_class_3;
var_10.var_8 = var_8;
var_10.var_9 = var_9;
var_10.var_10 = var_10;
var_10.run();
}
}
class Class8 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
Class4 var_6;
Class3 var_5;
Class2 var_4;
original_c1 latest_class_3;
Class6 var_8;
Class7 var_9;
Class8 var_10;
Class9 var_11;
public void run() {
System.out.println(8 + 9);
System.out.println(8 - 9);
System.out.println(8 * 9);
System.out.println(original_arr[0]);
original_ob1.original_real = true;
var_11 = new Class9();
var_11.var_1 = var_1;
var_11.original_ob1 = original_ob1;
var_11.original_unreal = original_unreal;
var_11.var_10 = var_10;
var_11.var_9 = var_9;
var_11.latest_class_3 = latest_class_3;
var_11.var_8 = var_8;
var_11.var_6 = var_6;
var_11.var_5 = var_5;
var_11.original_arr = original_arr;
var_11.var_4 = var_4;
original_ob1.original_callFunction(var_11);
}
}
class Class9 extends Runner {
Runner var_1;
original_c1 original_ob1;
boolean original_unreal;
Class8 var_10;
Class7 var_9;
original_c1 latest_class_3;
Class6 var_8;
Class4 var_6;
Class3 var_5;
int[] original_arr;
Class2 var_4;
public void run() {
var_6.var_1 = var_1;
var_6.original_ob1 = original_ob1;
var_6.original_arr = original_arr;
var_6.original_unreal = original_unreal;
var_6.latest_class_3 = latest_class_3;
var_6.var_4 = var_4;
var_6.var_5 = var_5;
var_6.var_6 = var_6;
var_6.var_1 = var_1;
var_6.original_ob1 = original_ob1;
var_6.original_unreal = original_unreal;
var_6.latest_class_3 = latest_class_3;
var_6.var_6 = var_6;
var_6.var_5 = var_5;
var_6.original_arr = original_arr;
var_6.var_4 = var_4;
var_6.run();
}
}
class Class4 extends Runner {
Runner var_1;
original_c1 original_ob1;
int[] original_arr;
boolean original_unreal;
original_c1 latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
var_1.run();
}
}
class Class10 extends Runner {
Runner var_12;
original_c1 original_c1Object1;
original_realMain latest_class_14;
public void run() {
var_12.run();
}
}
