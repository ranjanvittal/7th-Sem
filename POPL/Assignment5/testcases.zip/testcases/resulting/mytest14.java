class mytest14 {
public static void main(String[] original_micro_a) {
new original_new_mytest14().original_print(new Runner());
}
}
class original_new_mytest14 {
public void original_print(Runner var_1) {
original_Genarray original_looks;
int[] original_b;
int original_i;
Class1 var_2;
original_looks = new original_Genarray();
original_b = new int [1];
original_i = 0;
original_looks = new original_Genarray();
original_b = new int [101];
original_i = 0;
var_2 = new Class1();
var_2.var_1 = var_1;
var_2.original_b = original_b;
var_2.original_looks = original_looks;
var_2.original_i = original_i;
var_2.latest_class_3 = this;
original_looks.original_set(original_b, var_2);
}
}
class original_Genarray {
int original_size;
int original_iterator;
int[] original_array;
public void original_set(int[] original_b, Runner var_11) {
int original_i;
int original_j;
Class8 var_12;
original_i = 0;
original_j = 0;
original_array = original_b;
original_size = original_b.length;
original_iterator = 0;
original_i = 0;
var_12 = new Class8();
var_12.var_11 = var_11;
var_12.original_b = original_b;
var_12.original_j = original_j;
var_12.original_i = original_i;
var_12.latest_class_13 = this;
var_12.run();
}
public void original_print(Runner var_19) {
int original_ar;
original_ar = 0;
original_ar = original_array[original_iterator];
System.out.println(original_ar);
original_iterator = original_iterator + 1;
var_19.run();
}
}
class original_extra_array {
int[] original_first;
}
class original_extra_int {
int original_first;
}
class original_extra_boolean {
boolean original_first;
}
class Runner {
public void run() {
}
}
class Class3 extends Runner {
Runner var_1;
int[] original_b;
original_Genarray original_looks;
int original_i;
Class2 var_5;
original_new_mytest14 latest_class_3;
Class4 var_7;
Class5 var_8;
Class7 var_10;
public void run() {
if(original_i < 101)
{
var_7 = new Class4();
var_7.var_1 = var_1;
var_7.original_b = original_b;
var_7.original_looks = original_looks;
var_7.original_i = original_i;
var_7.var_5 = var_5;
var_7.latest_class_3 = latest_class_3;
var_7.var_7 = var_7;
var_7.var_8 = var_8;
var_7.run();
}
else
{
var_8 = new Class5();
var_8.var_1 = var_1;
var_8.original_b = original_b;
var_8.original_looks = original_looks;
var_8.original_i = original_i;
var_8.var_5 = var_5;
var_8.latest_class_3 = latest_class_3;
var_8.var_7 = var_7;
var_8.var_8 = var_8;
var_8.run();
}
}
}
class Class4 extends Runner {
Runner var_1;
int[] original_b;
original_Genarray original_looks;
int original_i;
Class2 var_5;
original_new_mytest14 latest_class_3;
Class4 var_7;
Class5 var_8;
Class7 var_10;
public void run() {
original_i = original_i + 1;
var_10 = new Class7();
var_10.var_1 = var_1;
var_10.original_b = original_b;
var_10.original_looks = original_looks;
var_10.var_8 = var_8;
var_10.var_7 = var_7;
var_10.original_i = original_i;
var_10.var_5 = var_5;
var_10.latest_class_3 = latest_class_3;
original_looks.original_print(var_10);
}
}
class Class7 extends Runner {
Runner var_1;
int[] original_b;
original_Genarray original_looks;
Class5 var_8;
Class4 var_7;
int original_i;
Class2 var_5;
original_new_mytest14 latest_class_3;
public void run() {
var_5.var_1 = var_1;
var_5.original_b = original_b;
var_5.original_looks = original_looks;
var_5.original_i = original_i;
var_5.var_5 = var_5;
var_5.latest_class_3 = latest_class_3;
var_5.run();
}
}
class Class5 extends Runner {
Runner var_1;
int[] original_b;
original_Genarray original_looks;
int original_i;
Class2 var_5;
original_new_mytest14 latest_class_3;
Class4 var_7;
Class5 var_8;
Class7 var_10;
public void run() {
var_1.run();
}
}
class Class2 extends Runner {
Runner var_1;
int[] original_b;
original_Genarray original_looks;
int original_i;
original_new_mytest14 latest_class_3;
Class2 var_5;
Class3 var_6;
public void run() {
var_5 = new Class2();
var_6 = new Class3();
var_6.var_1 = var_1;
var_6.original_b = original_b;
var_6.original_looks = original_looks;
var_6.original_i = original_i;
var_6.var_5 = var_5;
var_6.latest_class_3 = latest_class_3;
var_6.run();
}
}
class Class1 extends Runner {
Runner var_1;
int[] original_b;
original_Genarray original_looks;
int original_i;
original_new_mytest14 latest_class_3;
Class2 var_4;
public void run() {
var_4 = new Class2();
var_4.var_1 = var_1;
var_4.original_b = original_b;
var_4.original_looks = original_looks;
var_4.original_i = original_i;
var_4.latest_class_3 = latest_class_3;
var_4.run();
}
}
class Class9 extends Runner {
Runner var_11;
int[] original_b;
original_Genarray latest_class_13;
int original_j;
int original_i;
Class8 var_14;
Class10 var_16;
Class11 var_17;
public void run() {
if(original_i < 101)
{
var_16 = new Class10();
var_16.var_11 = var_11;
var_16.original_b = original_b;
var_16.latest_class_13 = latest_class_13;
var_16.original_j = original_j;
var_16.original_i = original_i;
var_16.var_14 = var_14;
var_16.var_16 = var_16;
var_16.var_17 = var_17;
var_16.run();
}
else
{
var_17 = new Class11();
var_17.var_11 = var_11;
var_17.original_b = original_b;
var_17.latest_class_13 = latest_class_13;
var_17.original_j = original_j;
var_17.original_i = original_i;
var_17.var_14 = var_14;
var_17.var_16 = var_16;
var_17.var_17 = var_17;
var_17.run();
}
}
}
class Class10 extends Runner {
Runner var_11;
int[] original_b;
original_Genarray latest_class_13;
int original_j;
int original_i;
Class8 var_14;
Class10 var_16;
Class11 var_17;
public void run() {
int[] final_1;
original_j = original_i * original_i;
final_1 = latest_class_13.original_array;
final_1[original_i] = original_j;
original_i = original_i + 1;
var_14.var_11 = var_11;
var_14.original_b = original_b;
var_14.latest_class_13 = latest_class_13;
var_14.original_j = original_j;
var_14.original_i = original_i;
var_14.var_14 = var_14;
var_14.run();
}
}
class Class11 extends Runner {
Runner var_11;
int[] original_b;
original_Genarray latest_class_13;
int original_j;
int original_i;
Class8 var_14;
Class10 var_16;
Class11 var_17;
public void run() {
var_11.run();
}
}
class Class8 extends Runner {
Runner var_11;
int[] original_b;
int original_j;
int original_i;
original_Genarray latest_class_13;
Class8 var_14;
Class9 var_15;
public void run() {
var_14 = new Class8();
var_15 = new Class9();
var_15.var_11 = var_11;
var_15.original_b = original_b;
var_15.latest_class_13 = latest_class_13;
var_15.original_j = original_j;
var_15.original_i = original_i;
var_15.var_14 = var_14;
var_15.run();
}
}
