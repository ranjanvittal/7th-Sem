class BubbleSort {
public static void main(String[] original_a) {
new original_____NewMainClass____().original_____Main____(0, new Runner());
}
}
class original_BBS {
int[] original_number;
int original_size;
int original_____1234Start4321____;
int original_____1234Sort4321____;
int original_____1234Print4321____;
int original_____1234Init4321____;
public void original_Start(int original_sz, Runner var_1) {
int original_aux01;
int original_____writeable____sz;
original_BBS original____tmp1;
int original____tmp0;
original_BBS original____tmp3;
int original____tmp2;
original_BBS original____tmp5;
int original____tmp4;
original_BBS original____tmp7;
int original____tmp6;
Class1 var_2;
original_aux01 = 0;
original_____writeable____sz = 0;
original____tmp1 = new original_BBS();
original____tmp0 = 0;
original____tmp3 = new original_BBS();
original____tmp2 = 0;
original____tmp5 = new original_BBS();
original____tmp4 = 0;
original____tmp7 = new original_BBS();
original____tmp6 = 0;
original_____writeable____sz = original_sz;
original____tmp1 = this;
var_2 = new Class1();
var_2.original____tmp4 = original____tmp4;
var_2.var_1 = var_1;
var_2.original_sz = original_sz;
var_2.original____tmp3 = original____tmp3;
var_2.original____tmp2 = original____tmp2;
var_2.original____tmp1 = original____tmp1;
var_2.original____tmp0 = original____tmp0;
var_2.original_____writeable____sz = original_____writeable____sz;
var_2.original_aux01 = original_aux01;
var_2.original____tmp7 = original____tmp7;
var_2.original____tmp6 = original____tmp6;
var_2.original____tmp5 = original____tmp5;
var_2.latest_class_3 = this;
original____tmp1.original_Init(original_____writeable____sz, var_2);
}
public void original_Sort(Runner var_7) {
int original_nt;
int original_i;
int original_aux02;
int original_aux04;
int original_aux05;
int original_aux06;
int original_aux07;
int original_j;
int original_t;
int original_____tmp8;
Class5 var_8;
original_nt = 0;
original_i = 0;
original_aux02 = 0;
original_aux04 = 0;
original_aux05 = 0;
original_aux06 = 0;
original_aux07 = 0;
original_j = 0;
original_t = 0;
original_____tmp8 = 0;
original_i = original_size - 1;
original_aux02 = 0 - 1;
var_8 = new Class5();
var_8.original_nt = original_nt;
var_8.original_j = original_j;
var_8.original_i = original_i;
var_8.original_____tmp8 = original_____tmp8;
var_8.original_aux07 = original_aux07;
var_8.original_aux06 = original_aux06;
var_8.original_aux05 = original_aux05;
var_8.original_aux04 = original_aux04;
var_8.original_aux02 = original_aux02;
var_8.original_t = original_t;
var_8.var_7 = var_7;
var_8.latest_class_9 = this;
var_8.run();
}
public void original_Print(Runner var_25) {
int original_j;
int original_____tmp9;
Class19 var_26;
original_j = 0;
original_____tmp9 = 0;
original_j = 0;
original_____tmp9 = original_size;
var_26 = new Class19();
var_26.original_j = original_j;
var_26.original_____tmp9 = original_____tmp9;
var_26.var_25 = var_25;
var_26.latest_class_27 = this;
var_26.run();
}
public void original_Init(int original_sz, Runner var_33) {
int original_____writeable____sz;
original_____writeable____sz = 0;
original_____writeable____sz = original_sz;
original_size = original_____writeable____sz;
original_number = new int [original_____writeable____sz];
original_number[0] = 20;
original_number[1] = 7;
original_number[2] = 12;
original_number[3] = 18;
original_number[4] = 2;
original_number[5] = 11;
original_number[6] = 6;
original_number[7] = 9;
original_number[8] = 19;
original_number[9] = 5;
original_____1234Init4321____ = 0;
var_33.run();
}
}
class original_____NewMainClass____ {
public void original_____Main____(int original_____arg_length____, Runner var_34) {
int original_____printMe____;
original_BBS original____tmp11;
int original____tmp10;
Class24 var_35;
original_____printMe____ = 0;
original____tmp11 = new original_BBS();
original____tmp10 = 0;
original____tmp11 = new original_BBS();
var_35 = new Class24();
var_35.original____tmp11 = original____tmp11;
var_35.var_34 = var_34;
var_35.original____tmp10 = original____tmp10;
var_35.original_____printMe____ = original_____printMe____;
var_35.original_____arg_length____ = original_____arg_length____;
var_35.latest_class_36 = this;
original____tmp11.original_Start(10, var_35);
}
}
class Runner {
public void run() {
}
}
class Class4 extends Runner {
int original____tmp4;
Runner var_1;
int original_sz;
original_BBS original____tmp3;
int original____tmp2;
original_BBS original____tmp1;
int original____tmp0;
int original_____writeable____sz;
original_BBS latest_class_3;
int original_aux01;
original_BBS original____tmp7;
int original____tmp6;
original_BBS original____tmp5;
public void run() {
original____tmp6 = original____tmp7.original_____1234Print4321____;
original_aux01 = original____tmp6;
latest_class_3.original_____1234Start4321____ = 0;
var_1.run();
}
}
class Class3 extends Runner {
int original____tmp4;
Runner var_1;
int original_sz;
original_BBS original____tmp3;
int original____tmp2;
original_BBS original____tmp1;
int original____tmp0;
int original_____writeable____sz;
original_BBS latest_class_3;
int original_aux01;
original_BBS original____tmp7;
int original____tmp6;
original_BBS original____tmp5;
Class4 var_6;
public void run() {
original____tmp4 = original____tmp5.original_____1234Sort4321____;
original_aux01 = original____tmp4;
original____tmp7 = latest_class_3;
var_6 = new Class4();
var_6.original____tmp4 = original____tmp4;
var_6.var_1 = var_1;
var_6.original_sz = original_sz;
var_6.original____tmp3 = original____tmp3;
var_6.original____tmp2 = original____tmp2;
var_6.original____tmp1 = original____tmp1;
var_6.original____tmp0 = original____tmp0;
var_6.original_____writeable____sz = original_____writeable____sz;
var_6.latest_class_3 = latest_class_3;
var_6.original_aux01 = original_aux01;
var_6.original____tmp7 = original____tmp7;
var_6.original____tmp6 = original____tmp6;
var_6.original____tmp5 = original____tmp5;
original____tmp7.original_Print(var_6);
}
}
class Class2 extends Runner {
int original____tmp4;
Runner var_1;
int original_sz;
original_BBS original____tmp3;
int original____tmp2;
original_BBS original____tmp1;
int original____tmp0;
int original_____writeable____sz;
original_BBS latest_class_3;
int original_aux01;
original_BBS original____tmp7;
int original____tmp6;
original_BBS original____tmp5;
Class3 var_5;
public void run() {
original____tmp2 = original____tmp3.original_____1234Print4321____;
original_aux01 = original____tmp2;
System.out.println(99999);
original____tmp5 = latest_class_3;
var_5 = new Class3();
var_5.original____tmp4 = original____tmp4;
var_5.var_1 = var_1;
var_5.original_sz = original_sz;
var_5.original____tmp3 = original____tmp3;
var_5.original____tmp2 = original____tmp2;
var_5.original____tmp1 = original____tmp1;
var_5.original____tmp0 = original____tmp0;
var_5.original_____writeable____sz = original_____writeable____sz;
var_5.latest_class_3 = latest_class_3;
var_5.original_aux01 = original_aux01;
var_5.original____tmp7 = original____tmp7;
var_5.original____tmp6 = original____tmp6;
var_5.original____tmp5 = original____tmp5;
original____tmp5.original_Sort(var_5);
}
}
class Class1 extends Runner {
int original____tmp4;
Runner var_1;
int original_sz;
original_BBS original____tmp3;
int original____tmp2;
original_BBS original____tmp1;
int original____tmp0;
int original_____writeable____sz;
int original_aux01;
original_BBS original____tmp7;
int original____tmp6;
original_BBS original____tmp5;
original_BBS latest_class_3;
Class2 var_4;
public void run() {
original____tmp0 = original____tmp1.original_____1234Init4321____;
original_aux01 = original____tmp0;
original____tmp3 = latest_class_3;
var_4 = new Class2();
var_4.original____tmp4 = original____tmp4;
var_4.var_1 = var_1;
var_4.original_sz = original_sz;
var_4.original____tmp3 = original____tmp3;
var_4.original____tmp2 = original____tmp2;
var_4.original____tmp1 = original____tmp1;
var_4.original____tmp0 = original____tmp0;
var_4.original_____writeable____sz = original_____writeable____sz;
var_4.latest_class_3 = latest_class_3;
var_4.original_aux01 = original_aux01;
var_4.original____tmp7 = original____tmp7;
var_4.original____tmp6 = original____tmp6;
var_4.original____tmp5 = original____tmp5;
original____tmp3.original_Print(var_4);
}
}
class Class6 extends Runner {
int original_nt;
int original_j;
int original_i;
int original_____tmp8;
original_BBS latest_class_9;
int original_aux07;
Class5 var_10;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Runner var_7;
int original_t;
Class7 var_12;
Class8 var_13;
Class10 var_15;
public void run() {
if(original_aux02 < original_i)
{
var_12 = new Class7();
var_12.original_nt = original_nt;
var_12.original_j = original_j;
var_12.original_i = original_i;
var_12.original_____tmp8 = original_____tmp8;
var_12.latest_class_9 = latest_class_9;
var_12.original_aux07 = original_aux07;
var_12.var_10 = var_10;
var_12.original_aux06 = original_aux06;
var_12.original_aux05 = original_aux05;
var_12.original_aux04 = original_aux04;
var_12.original_aux02 = original_aux02;
var_12.var_7 = var_7;
var_12.original_t = original_t;
var_12.var_12 = var_12;
var_12.var_13 = var_13;
var_12.run();
}
else
{
var_13 = new Class8();
var_13.original_nt = original_nt;
var_13.original_j = original_j;
var_13.original_i = original_i;
var_13.original_____tmp8 = original_____tmp8;
var_13.latest_class_9 = latest_class_9;
var_13.original_aux07 = original_aux07;
var_13.var_10 = var_10;
var_13.original_aux06 = original_aux06;
var_13.original_aux05 = original_aux05;
var_13.original_aux04 = original_aux04;
var_13.original_aux02 = original_aux02;
var_13.var_7 = var_7;
var_13.original_t = original_t;
var_13.var_12 = var_12;
var_13.var_13 = var_13;
var_13.run();
}
}
}
class Class7 extends Runner {
int original_nt;
int original_j;
int original_i;
int original_____tmp8;
original_BBS latest_class_9;
int original_aux07;
Class5 var_10;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Runner var_7;
int original_t;
Class7 var_12;
Class8 var_13;
Class10 var_15;
public void run() {
original_j = 1;
original_____tmp8 = original_i + 1;
var_15 = new Class10();
var_15.original_nt = original_nt;
var_15.original_j = original_j;
var_15.original_i = original_i;
var_15.var_13 = var_13;
var_15.original_____tmp8 = original_____tmp8;
var_15.var_12 = var_12;
var_15.latest_class_9 = latest_class_9;
var_15.original_aux07 = original_aux07;
var_15.original_aux06 = original_aux06;
var_15.var_10 = var_10;
var_15.original_aux05 = original_aux05;
var_15.original_aux04 = original_aux04;
var_15.original_aux02 = original_aux02;
var_15.original_t = original_t;
var_15.var_7 = var_7;
var_15.run();
}
}
class Class11 extends Runner {
int original_nt;
int original_j;
Class10 var_16;
int original_i;
Class8 var_13;
int original_____tmp8;
original_BBS latest_class_9;
Class7 var_12;
int original_aux07;
Class5 var_10;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Runner var_7;
int original_t;
Class12 var_18;
Class13 var_19;
Class15 var_21;
public void run() {
if(original_j < original_____tmp8)
{
var_18 = new Class12();
var_18.original_nt = original_nt;
var_18.original_j = original_j;
var_18.var_16 = var_16;
var_18.original_i = original_i;
var_18.var_13 = var_13;
var_18.original_____tmp8 = original_____tmp8;
var_18.latest_class_9 = latest_class_9;
var_18.var_12 = var_12;
var_18.original_aux07 = original_aux07;
var_18.var_10 = var_10;
var_18.original_aux06 = original_aux06;
var_18.original_aux05 = original_aux05;
var_18.original_aux04 = original_aux04;
var_18.original_aux02 = original_aux02;
var_18.var_7 = var_7;
var_18.original_t = original_t;
var_18.var_18 = var_18;
var_18.var_19 = var_19;
var_18.run();
}
else
{
var_19 = new Class13();
var_19.original_nt = original_nt;
var_19.original_j = original_j;
var_19.var_16 = var_16;
var_19.original_i = original_i;
var_19.var_13 = var_13;
var_19.original_____tmp8 = original_____tmp8;
var_19.latest_class_9 = latest_class_9;
var_19.var_12 = var_12;
var_19.original_aux07 = original_aux07;
var_19.var_10 = var_10;
var_19.original_aux06 = original_aux06;
var_19.original_aux05 = original_aux05;
var_19.original_aux04 = original_aux04;
var_19.original_aux02 = original_aux02;
var_19.var_7 = var_7;
var_19.original_t = original_t;
var_19.var_18 = var_18;
var_19.var_19 = var_19;
var_19.run();
}
}
}
class Class12 extends Runner {
int original_nt;
int original_j;
Class10 var_16;
int original_i;
Class8 var_13;
int original_____tmp8;
original_BBS latest_class_9;
Class7 var_12;
int original_aux07;
Class5 var_10;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Runner var_7;
int original_t;
Class12 var_18;
Class13 var_19;
Class15 var_21;
public void run() {
int[] final_1;
int[] final_2;
original_aux07 = original_j - 1;
final_1 = latest_class_9.original_number;
original_aux04 = final_1[original_aux07];
final_2 = latest_class_9.original_number;
original_aux05 = final_2[original_j];
var_21 = new Class15();
var_21.original_nt = original_nt;
var_21.latest_class_9 = latest_class_9;
var_21.original_t = original_t;
var_21.original_____tmp8 = original_____tmp8;
var_21.var_19 = var_19;
var_21.var_18 = var_18;
var_21.var_16 = var_16;
var_21.var_7 = var_7;
var_21.var_13 = var_13;
var_21.var_12 = var_12;
var_21.original_j = original_j;
var_21.original_i = original_i;
var_21.var_10 = var_10;
var_21.original_aux07 = original_aux07;
var_21.original_aux06 = original_aux06;
var_21.original_aux05 = original_aux05;
var_21.original_aux04 = original_aux04;
var_21.original_aux02 = original_aux02;
var_21.run();
}
}
class Class15 extends Runner {
int original_nt;
original_BBS latest_class_9;
int original_t;
int original_____tmp8;
Class13 var_19;
Class12 var_18;
Class10 var_16;
Runner var_7;
Class8 var_13;
Class7 var_12;
int original_j;
int original_i;
Class5 var_10;
int original_aux07;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Class16 var_22;
Class17 var_23;
Class18 var_24;
public void run() {
if(original_aux05 < original_aux04)
{
var_22 = new Class16();
var_24 = new Class18();
var_22.original_nt = original_nt;
var_22.latest_class_9 = latest_class_9;
var_22.original_t = original_t;
var_22.original_____tmp8 = original_____tmp8;
var_22.var_19 = var_19;
var_22.var_18 = var_18;
var_22.var_16 = var_16;
var_22.var_7 = var_7;
var_22.var_13 = var_13;
var_22.var_12 = var_12;
var_22.original_j = original_j;
var_22.original_i = original_i;
var_22.var_10 = var_10;
var_22.original_aux07 = original_aux07;
var_22.original_aux06 = original_aux06;
var_22.original_aux05 = original_aux05;
var_22.original_aux04 = original_aux04;
var_22.original_aux02 = original_aux02;
var_22.var_22 = var_22;
var_22.var_23 = var_23;
var_22.var_24 = var_24;
var_22.run();
}
else
{
var_23 = new Class17();
var_24 = new Class18();
var_23.original_nt = original_nt;
var_23.latest_class_9 = latest_class_9;
var_23.original_t = original_t;
var_23.original_____tmp8 = original_____tmp8;
var_23.var_19 = var_19;
var_23.var_18 = var_18;
var_23.var_16 = var_16;
var_23.var_7 = var_7;
var_23.var_13 = var_13;
var_23.var_12 = var_12;
var_23.original_j = original_j;
var_23.original_i = original_i;
var_23.var_10 = var_10;
var_23.original_aux07 = original_aux07;
var_23.original_aux06 = original_aux06;
var_23.original_aux05 = original_aux05;
var_23.original_aux04 = original_aux04;
var_23.original_aux02 = original_aux02;
var_23.var_22 = var_22;
var_23.var_23 = var_23;
var_23.var_24 = var_24;
var_23.run();
}
}
}
class Class16 extends Runner {
int original_nt;
original_BBS latest_class_9;
int original_t;
int original_____tmp8;
Class13 var_19;
Class12 var_18;
Class10 var_16;
Runner var_7;
Class8 var_13;
Class7 var_12;
int original_j;
int original_i;
Class5 var_10;
int original_aux07;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Class16 var_22;
Class17 var_23;
Class18 var_24;
public void run() {
int[] final_3;
int[] final_4;
int[] final_5;
int[] final_6;
original_aux06 = original_j - 1;
final_3 = latest_class_9.original_number;
original_t = final_3[original_aux06];
final_4 = latest_class_9.original_number;
final_5 = latest_class_9.original_number;
final_4[original_aux06] = final_5[original_j];
final_6 = latest_class_9.original_number;
final_6[original_j] = original_t;
var_24.original_nt = original_nt;
var_24.latest_class_9 = latest_class_9;
var_24.original_t = original_t;
var_24.original_____tmp8 = original_____tmp8;
var_24.var_19 = var_19;
var_24.var_18 = var_18;
var_24.var_16 = var_16;
var_24.var_7 = var_7;
var_24.var_13 = var_13;
var_24.var_12 = var_12;
var_24.original_j = original_j;
var_24.original_i = original_i;
var_24.var_10 = var_10;
var_24.original_aux07 = original_aux07;
var_24.original_aux06 = original_aux06;
var_24.original_aux05 = original_aux05;
var_24.original_aux04 = original_aux04;
var_24.original_aux02 = original_aux02;
var_24.var_22 = var_22;
var_24.var_23 = var_23;
var_24.var_24 = var_24;
var_24.original_nt = original_nt;
var_24.latest_class_9 = latest_class_9;
var_24.original_t = original_t;
var_24.original_____tmp8 = original_____tmp8;
var_24.var_19 = var_19;
var_24.var_18 = var_18;
var_24.var_16 = var_16;
var_24.var_7 = var_7;
var_24.var_13 = var_13;
var_24.var_12 = var_12;
var_24.original_j = original_j;
var_24.original_i = original_i;
var_24.var_10 = var_10;
var_24.original_aux07 = original_aux07;
var_24.original_aux06 = original_aux06;
var_24.original_aux05 = original_aux05;
var_24.original_aux04 = original_aux04;
var_24.original_aux02 = original_aux02;
var_24.var_22 = var_22;
var_24.var_23 = var_23;
var_24.var_24 = var_24;
var_24.run();
}
}
class Class17 extends Runner {
int original_nt;
original_BBS latest_class_9;
int original_t;
int original_____tmp8;
Class13 var_19;
Class12 var_18;
Class10 var_16;
Runner var_7;
Class8 var_13;
Class7 var_12;
int original_j;
int original_i;
Class5 var_10;
int original_aux07;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Class16 var_22;
Class17 var_23;
Class18 var_24;
public void run() {
original_nt = 0;
var_24.original_nt = original_nt;
var_24.latest_class_9 = latest_class_9;
var_24.original_t = original_t;
var_24.original_____tmp8 = original_____tmp8;
var_24.var_19 = var_19;
var_24.var_18 = var_18;
var_24.var_16 = var_16;
var_24.var_7 = var_7;
var_24.var_13 = var_13;
var_24.var_12 = var_12;
var_24.original_j = original_j;
var_24.original_i = original_i;
var_24.var_10 = var_10;
var_24.original_aux07 = original_aux07;
var_24.original_aux06 = original_aux06;
var_24.original_aux05 = original_aux05;
var_24.original_aux04 = original_aux04;
var_24.original_aux02 = original_aux02;
var_24.var_22 = var_22;
var_24.var_23 = var_23;
var_24.var_24 = var_24;
var_24.original_nt = original_nt;
var_24.latest_class_9 = latest_class_9;
var_24.original_t = original_t;
var_24.original_____tmp8 = original_____tmp8;
var_24.var_19 = var_19;
var_24.var_18 = var_18;
var_24.var_16 = var_16;
var_24.var_7 = var_7;
var_24.var_13 = var_13;
var_24.var_12 = var_12;
var_24.original_j = original_j;
var_24.original_i = original_i;
var_24.var_10 = var_10;
var_24.original_aux07 = original_aux07;
var_24.original_aux06 = original_aux06;
var_24.original_aux05 = original_aux05;
var_24.original_aux04 = original_aux04;
var_24.original_aux02 = original_aux02;
var_24.var_22 = var_22;
var_24.var_23 = var_23;
var_24.var_24 = var_24;
var_24.run();
}
}
class Class18 extends Runner {
int original_nt;
original_BBS latest_class_9;
int original_t;
int original_____tmp8;
Class13 var_19;
Class12 var_18;
Class10 var_16;
Runner var_7;
Class8 var_13;
Class7 var_12;
int original_j;
int original_i;
Class5 var_10;
int original_aux07;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Class16 var_22;
Class17 var_23;
Class18 var_24;
public void run() {
original_j = original_j + 1;
original_____tmp8 = original_i + 1;
var_16.original_nt = original_nt;
var_16.latest_class_9 = latest_class_9;
var_16.original_t = original_t;
var_16.original_____tmp8 = original_____tmp8;
var_16.var_16 = var_16;
var_16.var_7 = var_7;
var_16.var_13 = var_13;
var_16.var_12 = var_12;
var_16.original_j = original_j;
var_16.original_i = original_i;
var_16.var_10 = var_10;
var_16.original_aux07 = original_aux07;
var_16.original_aux06 = original_aux06;
var_16.original_aux05 = original_aux05;
var_16.original_aux04 = original_aux04;
var_16.original_aux02 = original_aux02;
var_16.run();
}
}
class Class13 extends Runner {
int original_nt;
int original_j;
Class10 var_16;
int original_i;
Class8 var_13;
int original_____tmp8;
original_BBS latest_class_9;
Class7 var_12;
int original_aux07;
Class5 var_10;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Runner var_7;
int original_t;
Class12 var_18;
Class13 var_19;
Class15 var_21;
public void run() {
original_i = original_i - 1;
var_10.original_nt = original_nt;
var_10.original_j = original_j;
var_10.original_i = original_i;
var_10.original_____tmp8 = original_____tmp8;
var_10.latest_class_9 = latest_class_9;
var_10.original_aux07 = original_aux07;
var_10.var_10 = var_10;
var_10.original_aux06 = original_aux06;
var_10.original_aux05 = original_aux05;
var_10.original_aux04 = original_aux04;
var_10.original_aux02 = original_aux02;
var_10.var_7 = var_7;
var_10.original_t = original_t;
var_10.run();
}
}
class Class10 extends Runner {
int original_nt;
int original_j;
int original_i;
Class8 var_13;
int original_____tmp8;
Class7 var_12;
original_BBS latest_class_9;
int original_aux07;
int original_aux06;
Class5 var_10;
int original_aux05;
int original_aux04;
int original_aux02;
int original_t;
Runner var_7;
Class10 var_16;
Class11 var_17;
public void run() {
var_16 = new Class10();
var_17 = new Class11();
var_17.original_nt = original_nt;
var_17.original_j = original_j;
var_17.var_16 = var_16;
var_17.original_i = original_i;
var_17.var_13 = var_13;
var_17.original_____tmp8 = original_____tmp8;
var_17.latest_class_9 = latest_class_9;
var_17.var_12 = var_12;
var_17.original_aux07 = original_aux07;
var_17.var_10 = var_10;
var_17.original_aux06 = original_aux06;
var_17.original_aux05 = original_aux05;
var_17.original_aux04 = original_aux04;
var_17.original_aux02 = original_aux02;
var_17.var_7 = var_7;
var_17.original_t = original_t;
var_17.run();
}
}
class Class8 extends Runner {
int original_nt;
int original_j;
int original_i;
int original_____tmp8;
original_BBS latest_class_9;
int original_aux07;
Class5 var_10;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
Runner var_7;
int original_t;
Class7 var_12;
Class8 var_13;
Class10 var_15;
public void run() {
latest_class_9.original_____1234Sort4321____ = 0;
var_7.run();
}
}
class Class5 extends Runner {
int original_nt;
int original_j;
int original_i;
int original_____tmp8;
int original_aux07;
int original_aux06;
int original_aux05;
int original_aux04;
int original_aux02;
int original_t;
Runner var_7;
original_BBS latest_class_9;
Class5 var_10;
Class6 var_11;
public void run() {
var_10 = new Class5();
var_11 = new Class6();
var_11.original_nt = original_nt;
var_11.original_j = original_j;
var_11.original_i = original_i;
var_11.original_____tmp8 = original_____tmp8;
var_11.latest_class_9 = latest_class_9;
var_11.original_aux07 = original_aux07;
var_11.var_10 = var_10;
var_11.original_aux06 = original_aux06;
var_11.original_aux05 = original_aux05;
var_11.original_aux04 = original_aux04;
var_11.original_aux02 = original_aux02;
var_11.var_7 = var_7;
var_11.original_t = original_t;
var_11.run();
}
}
class Class20 extends Runner {
original_BBS latest_class_27;
int original_j;
Class19 var_28;
int original_____tmp9;
Runner var_25;
Class21 var_30;
Class22 var_31;
public void run() {
if(original_j < original_____tmp9)
{
var_30 = new Class21();
var_30.latest_class_27 = latest_class_27;
var_30.original_j = original_j;
var_30.var_28 = var_28;
var_30.original_____tmp9 = original_____tmp9;
var_30.var_25 = var_25;
var_30.var_30 = var_30;
var_30.var_31 = var_31;
var_30.run();
}
else
{
var_31 = new Class22();
var_31.latest_class_27 = latest_class_27;
var_31.original_j = original_j;
var_31.var_28 = var_28;
var_31.original_____tmp9 = original_____tmp9;
var_31.var_25 = var_25;
var_31.var_30 = var_30;
var_31.var_31 = var_31;
var_31.run();
}
}
}
class Class21 extends Runner {
original_BBS latest_class_27;
int original_j;
Class19 var_28;
int original_____tmp9;
Runner var_25;
Class21 var_30;
Class22 var_31;
public void run() {
int[] final_7;
int final_8;
final_7 = latest_class_27.original_number;
System.out.println(final_7[original_j]);
original_j = original_j + 1;
final_8 = latest_class_27.original_size;
original_____tmp9 = final_8;
var_28.latest_class_27 = latest_class_27;
var_28.original_j = original_j;
var_28.var_28 = var_28;
var_28.original_____tmp9 = original_____tmp9;
var_28.var_25 = var_25;
var_28.run();
}
}
class Class22 extends Runner {
original_BBS latest_class_27;
int original_j;
Class19 var_28;
int original_____tmp9;
Runner var_25;
Class21 var_30;
Class22 var_31;
public void run() {
latest_class_27.original_____1234Print4321____ = 0;
var_25.run();
}
}
class Class19 extends Runner {
int original_j;
int original_____tmp9;
Runner var_25;
original_BBS latest_class_27;
Class19 var_28;
Class20 var_29;
public void run() {
var_28 = new Class19();
var_29 = new Class20();
var_29.latest_class_27 = latest_class_27;
var_29.original_j = original_j;
var_29.var_28 = var_28;
var_29.original_____tmp9 = original_____tmp9;
var_29.var_25 = var_25;
var_29.run();
}
}
class Class24 extends Runner {
original_BBS original____tmp11;
Runner var_34;
int original____tmp10;
int original_____printMe____;
int original_____arg_length____;
original_____NewMainClass____ latest_class_36;
public void run() {
original____tmp10 = original____tmp11.original_____1234Start4321____;
original_____printMe____ = original____tmp10;
System.out.println(original_____printMe____);
var_34.run();
}
}
