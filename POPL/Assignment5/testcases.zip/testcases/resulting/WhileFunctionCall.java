class WhileFunctionCall {
public static void main(String[] original_a) {
new original_realMain().original_mainFunction(new Runner());
}
}
class original_c1 {
boolean original_real;
public void original_callFunction(original_c3 original_object, Runner var_1) {
int original_aux;
original_c1 original_c3Object1;
Class1 var_2;
original_aux = 0;
original_c3Object1 = new original_c1();
original_c3Object1 = new original_c1();
original_c3Object1 = this;
original_aux = original_object.original_a;
original_aux = original_aux - 15;
var_2 = new Class1();
var_2.var_1 = var_1;
var_2.original_c3Object1 = original_c3Object1;
var_2.original_aux = original_aux;
var_2.original_object = original_object;
var_2.latest_class_3 = this;
var_2.run();
}
}
class original_c2 {
int original_a;
}
class original_c3 extends original_c2{
}
class original_realMain {
public void original_mainFunction(Runner var_10) {
boolean original_b1;
original_c1 original_c1Object1;
original_c3 original_c3Object1;
Class7 var_11;
original_b1 = false;
original_c1Object1 = new original_c1();
original_c3Object1 = new original_c3();
original_c1Object1 = new original_c1();
original_c3Object1 = new original_c3();
original_c3Object1.original_a = 15;
original_c1Object1.original_real = false;
var_11 = new Class7();
var_11.var_10 = var_10;
var_11.original_c3Object1 = original_c3Object1;
var_11.original_b1 = original_b1;
var_11.original_c1Object1 = original_c1Object1;
var_11.latest_class_12 = this;
original_c1Object1.original_callFunction(original_c3Object1, var_11);
}
}
class Runner {
public void run() {
}
}
class Class2 extends Runner {
Runner var_1;
original_c1 original_c3Object1;
int original_aux;
original_c3 original_object;
Class1 var_4;
original_c1 latest_class_3;
Class3 var_6;
Class4 var_7;
Class6 var_9;
public void run() {
if(original_aux < 1)
{
var_6 = new Class3();
var_6.var_1 = var_1;
var_6.original_c3Object1 = original_c3Object1;
var_6.original_aux = original_aux;
var_6.original_object = original_object;
var_6.var_4 = var_4;
var_6.latest_class_3 = latest_class_3;
var_6.var_6 = var_6;
var_6.var_7 = var_7;
var_6.run();
}
else
{
var_7 = new Class4();
var_7.var_1 = var_1;
var_7.original_c3Object1 = original_c3Object1;
var_7.original_aux = original_aux;
var_7.original_object = original_object;
var_7.var_4 = var_4;
var_7.latest_class_3 = latest_class_3;
var_7.var_6 = var_6;
var_7.var_7 = var_7;
var_7.run();
}
}
}
class Class3 extends Runner {
Runner var_1;
original_c1 original_c3Object1;
int original_aux;
original_c3 original_object;
Class1 var_4;
original_c1 latest_class_3;
Class3 var_6;
Class4 var_7;
Class6 var_9;
public void run() {
latest_class_3.original_real = true;
original_object.original_a = 16;
var_9 = new Class6();
var_9.var_1 = var_1;
var_9.original_c3Object1 = original_c3Object1;
var_9.original_aux = original_aux;
var_9.original_object = original_object;
var_9.var_7 = var_7;
var_9.var_6 = var_6;
var_9.latest_class_3 = latest_class_3;
var_9.var_4 = var_4;
original_c3Object1.original_callFunction(original_object, var_9);
}
}
class Class6 extends Runner {
Runner var_1;
original_c1 original_c3Object1;
int original_aux;
original_c3 original_object;
Class4 var_7;
Class3 var_6;
original_c1 latest_class_3;
Class1 var_4;
public void run() {
original_aux = original_object.original_a;
original_aux = original_aux - 15;
var_4.var_1 = var_1;
var_4.original_c3Object1 = original_c3Object1;
var_4.original_aux = original_aux;
var_4.original_object = original_object;
var_4.latest_class_3 = latest_class_3;
var_4.var_4 = var_4;
var_4.run();
}
}
class Class4 extends Runner {
Runner var_1;
original_c1 original_c3Object1;
int original_aux;
original_c3 original_object;
Class1 var_4;
original_c1 latest_class_3;
Class3 var_6;
Class4 var_7;
Class6 var_9;
public void run() {
latest_class_3.original_real = false;
var_1.run();
}
}
class Class1 extends Runner {
Runner var_1;
original_c1 original_c3Object1;
int original_aux;
original_c3 original_object;
original_c1 latest_class_3;
Class1 var_4;
Class2 var_5;
public void run() {
var_4 = new Class1();
var_5 = new Class2();
var_5.var_1 = var_1;
var_5.original_c3Object1 = original_c3Object1;
var_5.original_aux = original_aux;
var_5.original_object = original_object;
var_5.var_4 = var_4;
var_5.latest_class_3 = latest_class_3;
var_5.run();
}
}
class Class8 extends Runner {
Runner var_10;
boolean original_b1;
original_c3 original_c3Object1;
original_c1 original_c1Object1;
original_realMain latest_class_12;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
if(original_b1)
{
var_14 = new Class9();
var_16 = new Class11();
var_14.var_10 = var_10;
var_14.original_b1 = original_b1;
var_14.original_c3Object1 = original_c3Object1;
var_14.original_c1Object1 = original_c1Object1;
var_14.latest_class_12 = latest_class_12;
var_14.var_14 = var_14;
var_14.var_15 = var_15;
var_14.var_16 = var_16;
var_14.run();
}
else
{
var_15 = new Class10();
var_16 = new Class11();
var_15.var_10 = var_10;
var_15.original_b1 = original_b1;
var_15.original_c3Object1 = original_c3Object1;
var_15.original_c1Object1 = original_c1Object1;
var_15.latest_class_12 = latest_class_12;
var_15.var_14 = var_14;
var_15.var_15 = var_15;
var_15.var_16 = var_16;
var_15.run();
}
}
}
class Class9 extends Runner {
Runner var_10;
boolean original_b1;
original_c3 original_c3Object1;
original_c1 original_c1Object1;
original_realMain latest_class_12;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
System.out.println(1);
var_16.var_10 = var_10;
var_16.original_b1 = original_b1;
var_16.original_c3Object1 = original_c3Object1;
var_16.original_c1Object1 = original_c1Object1;
var_16.latest_class_12 = latest_class_12;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.var_10 = var_10;
var_16.original_b1 = original_b1;
var_16.original_c3Object1 = original_c3Object1;
var_16.original_c1Object1 = original_c1Object1;
var_16.latest_class_12 = latest_class_12;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.run();
}
}
class Class10 extends Runner {
Runner var_10;
boolean original_b1;
original_c3 original_c3Object1;
original_c1 original_c1Object1;
original_realMain latest_class_12;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
System.out.println(0);
var_16.var_10 = var_10;
var_16.original_b1 = original_b1;
var_16.original_c3Object1 = original_c3Object1;
var_16.original_c1Object1 = original_c1Object1;
var_16.latest_class_12 = latest_class_12;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.var_10 = var_10;
var_16.original_b1 = original_b1;
var_16.original_c3Object1 = original_c3Object1;
var_16.original_c1Object1 = original_c1Object1;
var_16.latest_class_12 = latest_class_12;
var_16.var_14 = var_14;
var_16.var_15 = var_15;
var_16.var_16 = var_16;
var_16.run();
}
}
class Class11 extends Runner {
Runner var_10;
boolean original_b1;
original_c3 original_c3Object1;
original_c1 original_c1Object1;
original_realMain latest_class_12;
Class9 var_14;
Class10 var_15;
Class11 var_16;
public void run() {
var_10.run();
}
}
class Class7 extends Runner {
Runner var_10;
original_c3 original_c3Object1;
boolean original_b1;
original_c1 original_c1Object1;
original_realMain latest_class_12;
Class8 var_13;
public void run() {
original_b1 = original_c1Object1.original_real;
var_13 = new Class8();
var_13.var_10 = var_10;
var_13.original_b1 = original_b1;
var_13.original_c3Object1 = original_c3Object1;
var_13.original_c1Object1 = original_c1Object1;
var_13.latest_class_12 = latest_class_12;
var_13.run();
}
}
