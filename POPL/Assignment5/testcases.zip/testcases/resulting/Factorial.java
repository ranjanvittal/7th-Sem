class Factorial {
public static void main(String[] original_a) {
new original_____NewMainClass____().original_____Main____(0, new Runner());
}
}
class original_Fac {
int original_____1234ComputeFac4321____;
public void original_ComputeFac(int original_num, Runner var_1) {
int original_num_aux;
int original_____writeable____num;
int original_____tmp0;
original_Fac original____tmp4;
int original____tmp3;
Class1 var_2;
original_num_aux = 0;
original_____writeable____num = 0;
original_____tmp0 = 0;
original____tmp4 = new original_Fac();
original____tmp3 = 0;
original_____writeable____num = original_num;
var_2 = new Class1();
var_2.var_1 = var_1;
var_2.original____tmp4 = original____tmp4;
var_2.original____tmp3 = original____tmp3;
var_2.original_____tmp0 = original_____tmp0;
var_2.original_____writeable____num = original_____writeable____num;
var_2.original_num_aux = original_num_aux;
var_2.original_num = original_num;
var_2.latest_class_3 = this;
var_2.run();
}
}
class original_____NewMainClass____ {
public void original_____Main____(int original_____arg_length____, Runner var_8) {
int original_____printMe____;
original_Fac original____tmp6;
int original____tmp5;
Class6 var_9;
original_____printMe____ = 0;
original____tmp6 = new original_Fac();
original____tmp5 = 0;
original____tmp6 = new original_Fac();
var_9 = new Class6();
var_9.original____tmp6 = original____tmp6;
var_9.original____tmp5 = original____tmp5;
var_9.var_8 = var_8;
var_9.original_____printMe____ = original_____printMe____;
var_9.original_____arg_length____ = original_____arg_length____;
var_9.latest_class_10 = this;
original____tmp6.original_ComputeFac(10, var_9);
}
}
class Runner {
public void run() {
}
}
class Class1 extends Runner {
Runner var_1;
original_Fac original____tmp4;
int original____tmp3;
int original_____tmp0;
int original_____writeable____num;
int original_num_aux;
int original_num;
original_Fac latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
if(original_____writeable____num < 1)
{
var_4 = new Class2();
var_6 = new Class4();
var_4.var_1 = var_1;
var_4.original____tmp4 = original____tmp4;
var_4.original____tmp3 = original____tmp3;
var_4.original_____tmp0 = original_____tmp0;
var_4.original_____writeable____num = original_____writeable____num;
var_4.original_num_aux = original_num_aux;
var_4.original_num = original_num;
var_4.latest_class_3 = latest_class_3;
var_4.var_4 = var_4;
var_4.var_5 = var_5;
var_4.var_6 = var_6;
var_4.run();
}
else
{
var_5 = new Class3();
var_6 = new Class4();
var_5.var_1 = var_1;
var_5.original____tmp4 = original____tmp4;
var_5.original____tmp3 = original____tmp3;
var_5.original_____tmp0 = original_____tmp0;
var_5.original_____writeable____num = original_____writeable____num;
var_5.original_num_aux = original_num_aux;
var_5.original_num = original_num;
var_5.latest_class_3 = latest_class_3;
var_5.var_4 = var_4;
var_5.var_5 = var_5;
var_5.var_6 = var_6;
var_5.run();
}
}
}
class Class2 extends Runner {
Runner var_1;
original_Fac original____tmp4;
int original____tmp3;
int original_____tmp0;
int original_____writeable____num;
int original_num_aux;
int original_num;
original_Fac latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
original_num_aux = 1;
var_6.var_1 = var_1;
var_6.original____tmp4 = original____tmp4;
var_6.original____tmp3 = original____tmp3;
var_6.original_____tmp0 = original_____tmp0;
var_6.original_____writeable____num = original_____writeable____num;
var_6.original_num_aux = original_num_aux;
var_6.original_num = original_num;
var_6.latest_class_3 = latest_class_3;
var_6.var_4 = var_4;
var_6.var_5 = var_5;
var_6.var_6 = var_6;
var_6.var_1 = var_1;
var_6.original____tmp4 = original____tmp4;
var_6.original____tmp3 = original____tmp3;
var_6.original_____tmp0 = original_____tmp0;
var_6.original_____writeable____num = original_____writeable____num;
var_6.original_num_aux = original_num_aux;
var_6.original_num = original_num;
var_6.latest_class_3 = latest_class_3;
var_6.var_4 = var_4;
var_6.var_5 = var_5;
var_6.var_6 = var_6;
var_6.run();
}
}
class Class3 extends Runner {
Runner var_1;
original_Fac original____tmp4;
int original____tmp3;
int original_____tmp0;
int original_____writeable____num;
int original_num_aux;
int original_num;
original_Fac latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
original____tmp4 = latest_class_3;
var_7 = new Class5();
var_7.original____tmp4 = original____tmp4;
var_7.var_1 = var_1;
var_7.original____tmp3 = original____tmp3;
var_7.latest_class_3 = latest_class_3;
var_7.original_____tmp0 = original_____tmp0;
var_7.original_num_aux = original_num_aux;
var_7.var_6 = var_6;
var_7.var_5 = var_5;
var_7.original_num = original_num;
var_7.original_____writeable____num = original_____writeable____num;
var_7.var_4 = var_4;
original____tmp4.original_ComputeFac(original_____writeable____num - 1, var_7);
}
}
class Class5 extends Runner {
original_Fac original____tmp4;
Runner var_1;
int original____tmp3;
original_Fac latest_class_3;
int original_____tmp0;
int original_num_aux;
Class4 var_6;
Class3 var_5;
int original_num;
int original_____writeable____num;
Class2 var_4;
public void run() {
original____tmp3 = original____tmp4.original_____1234ComputeFac4321____;
original_____tmp0 = original____tmp3;
original_num_aux = original_____writeable____num * original_____tmp0;
var_6.var_1 = var_1;
var_6.original____tmp4 = original____tmp4;
var_6.original____tmp3 = original____tmp3;
var_6.original_____tmp0 = original_____tmp0;
var_6.original_____writeable____num = original_____writeable____num;
var_6.original_num_aux = original_num_aux;
var_6.original_num = original_num;
var_6.latest_class_3 = latest_class_3;
var_6.var_4 = var_4;
var_6.var_5 = var_5;
var_6.var_6 = var_6;
var_6.original____tmp4 = original____tmp4;
var_6.var_1 = var_1;
var_6.original____tmp3 = original____tmp3;
var_6.latest_class_3 = latest_class_3;
var_6.original_____tmp0 = original_____tmp0;
var_6.original_num_aux = original_num_aux;
var_6.var_6 = var_6;
var_6.var_5 = var_5;
var_6.original_num = original_num;
var_6.original_____writeable____num = original_____writeable____num;
var_6.var_4 = var_4;
var_6.run();
}
}
class Class4 extends Runner {
Runner var_1;
original_Fac original____tmp4;
int original____tmp3;
int original_____tmp0;
int original_____writeable____num;
int original_num_aux;
int original_num;
original_Fac latest_class_3;
Class2 var_4;
Class3 var_5;
Class4 var_6;
Class5 var_7;
public void run() {
latest_class_3.original_____1234ComputeFac4321____ = original_num_aux;
var_1.run();
}
}
class Class6 extends Runner {
original_Fac original____tmp6;
int original____tmp5;
Runner var_8;
int original_____printMe____;
int original_____arg_length____;
original_____NewMainClass____ latest_class_10;
public void run() {
original____tmp5 = original____tmp6.original_____1234ComputeFac4321____;
original_____printMe____ = original____tmp5;
System.out.println(original_____printMe____);
var_8.run();
}
}
