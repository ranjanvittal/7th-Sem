Yes
No
No
