Yes
Yes
No
Yes
