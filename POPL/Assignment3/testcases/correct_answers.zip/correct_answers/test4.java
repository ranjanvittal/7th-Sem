Yes
No
