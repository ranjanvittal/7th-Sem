Yes
Yes
Yes
Yes
No
No
