Yes
No
No
No
