No
No
No
No
Yes
