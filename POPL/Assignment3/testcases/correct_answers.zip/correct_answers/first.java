No
Yes
Yes
No
