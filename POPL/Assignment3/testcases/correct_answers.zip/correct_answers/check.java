No
Yes
Yes
No
No
