Yes
Yes
