No
Yes
