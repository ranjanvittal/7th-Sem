No
No
No
No
Yes
Yes
Yes
Yes
