No
Yes
No
Yes
Yes
