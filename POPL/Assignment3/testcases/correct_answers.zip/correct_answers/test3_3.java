No
No
Yes
No
